#pragma once
#include <vector>
#include <string>
#include <queue>
class Graph8 {
private:
    int n;//кол-во вершин
    std::vector<std::vector<int>> adj;//матрица смежности 
    bool validateMatrix() const;//проверка (квадрат, 0 1, симметрия
public:
    Graph8();//по умолч
    explicit Graph8(const std::string& filename);//из файла
    Graph8(int size);//для генерации
    Graph8(const std::vector<std::vector<int>>& matrix);//из матрицы
    void saveToFile(const std::string& filename) const;//сохранение
    void loadFromFile(const std::string& filename);//загрузка
    std::vector<int> citiesWithExactStops(int start, int L) const;//города с Л пересадками
    void printResult(int start, int L) const;//вывод результата
    void printMatrix() const;//вывод матрицы
    int getVertexCount() const { return n; }//геттер
    static Graph8 fromKeyboard();//ввод с клавы
    static Graph8 fromRandom();//случайный
    static Graph8 fromFile();//из файла
};