﻿#define NOMINMAX
#include <iostream>
#include <limits>
#include <windows.h>
#include "Graf1.h"
#include "Graf4.h"
#include "utils.h"
#include "Graf8.h"
void menu_task1();
void menu_task2();
void menu_task3();
int main() {
    ::SetConsoleCP(1251);
    ::SetConsoleOutputCP(1251);
    ::setlocale(LC_ALL, "Russian");
    int choice;
    do {
        std::cout << "\n\t\t~~ Лабораторная работа №21 (Графы) ~~\n\n";
        std::cout << "\t1. Задача 1 – Степени вершин (Graf1)\n";
        std::cout << "\t2. Задача 2 – BFS ориентированного графа (Graf4)\n";
        std::cout << "\t3. Задача 3 – Города с пересадками (Graf8)\n";
        std::cout << "\t0. Выход\n";
        choice = Utils::get_int("\n\tВыбери задание: ");
        while (choice < 0 || choice > 3) {
            std::cout << "\n\tОшибочка( выбери от 0 до 3!\n";
            choice = Utils::get_int("\n\tВыбери задание: ");
        }
        ::system("cls");
        switch (choice) {
        case 1: menu_task1(); break;
        case 2: menu_task2(); break;
        case 3: menu_task3(); break;
        case 0: std::cout << "\n\tПока-пока))\n\n"; break;
        }
        if (choice != 0) {
            std::cout << "\n\tНажми Enter для возврата в меню...";
            std::cin.get();
            std::cin.get();
            ::system("cls");
        }
    } while (choice != 0);
    return 0;
}
void menu_task1() {
    std::cout << "\n\t~~ Задача 1 – Степени вершин графа ~~\n";
    std::cout << "\n\tКак создать граф?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    Graph g;
    if (method == 1) g = Graph::fromKeyboard();
    else if (method == 2) g = Graph::fromRandom();
    else g = Graph::fromFile();
    if (g.getVertexCount() == 0) {
        std::cout << "\n\tОшибочка( не удалось загрузить граф!\n";
        std::cin.get();
        return;
    }
    g.printMatrix();
    g.printDegrees();
    std::cout << R"(
   |\      _,,,---,,_
   /,`.-'`'    -.  ;-;;,_
  |,4-  ) )-,_..;\ (  `'-'
 '---''(_/--'  `-'\_) )" << "\n";
    std::cin.get();
}
void menu_task2() {
    std::cout << "\n\t~~ Задача 2 – BFS ориентированного графа (Graf4) ~~\n";
    std::cout << "\n\tКак заполнить данные?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    Graph4 g;
    if (method == 1) g = Graph4::fromKeyboard();
    else if (method == 2) g = Graph4::fromRandom();
    else g = Graph4::fromFile();
    if (g.getVertexCount() == 0) {
        std::cout << "\n\tОшибочка( не удалось загрузить граф!\n";
        std::cin.get();
        return;
    }
    std::cout << "\n\tГраф загружен! Вершин: " << g.getVertexCount() << "\n";
    g.printMatrix();
    int start = Utils::get_int("\n\tВведи начальную вершину (1-" + std::to_string(g.getVertexCount()) + "): ");
    g.printBFS(start);
    std::cout << R"(
                                      ___
             |\__/,|   (`\        _.-|   |          |\__/,|   (`\
             |o o  |__ _) )      {   |   |          |o o  |__ _) )
           _.( T   )  `  /        "-.|___|        _.( T   )  `  /
 n n._    ((_ `^--' /_<  \         .--'-`-.     _((_ `^--' /_<  \
 <" _ }=- `` `-'(((/  (((/       .+|______|__.-||__)`-'(((/  (((/)" << "\n";
    std::cin.get();
}
void menu_task3() {
    std::cout << "\n\t~~ Задача 3 – Города с пересадками (Graf8) ~~\n";
    std::cout << "\n\tКак заполнить данные?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    Graph8 g;
    if (method == 1) g = Graph8::fromKeyboard();
    else if (method == 2) g = Graph8::fromRandom();
    else g = Graph8::fromFile();
    if (g.getVertexCount() == 0) {
        std::cout << "\n\tОшибочка( не удалось загрузить граф!\n";
        std::cin.get();
        return;
    }
    g.printMatrix();
    int K = Utils::get_int("\n\tВведи начальный город (1-" + std::to_string(g.getVertexCount()) + "): ");
    int L = Utils::get_int("\n\tВведи количество пересадок: ");
    g.printResult(K, L);
    std::cout << R"(
                                                _
                   |\___/|                      \\
                   )     (    |\_/|              ||
                  =\     /=   )a a `,_.-""""-.  //
                    )===(    =\Y_= /          \//
                   /     \     `"`\       /    /
                   |     |         |    \ |   /
                  /       \         \   /- \  \
                  \       /         || |  // /`
        jgs_/\_/\_/\_   _/_/\_/\_/\_((_|\((_//\_/\_/\_/\_)" << "\n";
    std::cin.get();
}