#pragma once
#include <vector>
#include <string>
#include <queue>
class Graph4 {
private:
    int n;//кол-во вершин
    std::vector<std::vector<int>> adj;//мтрц смежности (веса)
    std::vector<int> bfs(int start) const;//поиск бфс
    bool validateMatrix() const;//проверка матрицы
public:
    Graph4();//по умолч
    explicit Graph4(const std::string& filename);//из файла
    Graph4(int size);//для генерации
    Graph4(const std::vector<std::vector<int>>& matrix);//из матрицы
    void saveToFile(const std::string& filename) const;//сохранение
    void loadFromFile(const std::string& filename);//загрузка
    void printBFS(int start) const;//вывод БФС
    void printMatrix() const;//вывод матрицы
    int getVertexCount() const { return n; }
    static Graph4 fromKeyboard();//ввод с клавы
    static Graph4 fromRandom();//случайный
    static Graph4 fromFile();//из файла
};