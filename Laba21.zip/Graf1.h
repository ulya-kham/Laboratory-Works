#pragma once
#include <vector>
#include <string>
class Graph {
private:
    int n;//количество вершин
    std::vector<std::vector<int>> adj;//матрица смежности
    std::vector<int> degrees;//степени вершин
    void calcDegrees();//расчт степеней (петли дважды)
    bool validateMatrix() const;//проверка матрицы
public:
    Graph();//по умолч
    explicit Graph(const std::string& filename);//из файла
    Graph(int size);//для генерации
    Graph(const std::vector<std::vector<int>>& matrix);//из матрицы
    ~Graph();//дестр
    static Graph fromKeyboard();//ввод с клавы
    static Graph fromRandom();//случайный
    static Graph fromFile();//из файла
    void saveToFile(const std::string& filename) const;//сохранение
    void loadFromFile(const std::string& filename);//загрузка
    void printDegrees() const;//вывод степеней
    void printMatrix() const;//вывод матрицы
    int getVertexCount() const { return n; }//геттер
};