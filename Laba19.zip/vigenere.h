#pragma once
#include <string>
#include <map>
class VigenereCipher {
private:
    std::string alphabet;//алфавит
    std::map<char, int> char_to_num;//буква-номер
    std::map<int, char> num_to_char;//номер-буква
    std::string key;//ключ
    void build_tables();//построение таблиц
    std::string extend_key(const std::string& text) const;//повтор ключа
public:
    explicit VigenereCipher(const std::string& key_word);//констр
    std::string encrypt(const std::string& text) const;//шифрование
    std::string decrypt(const std::string& cipher) const;//дешифрование
    void print_table() const;//вывод таблицы Виженера
    std::string get_key() const { return key; }//геттер ключа
};