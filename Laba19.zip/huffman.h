#pragma once
#include <string>
#include <vector>
#include <map>
#include <queue>
class HuffmanNode {
private:
    char sym;//символ
    int freq;//частота
    HuffmanNode* left;//левый
    HuffmanNode* right;//правый
public:
    HuffmanNode(char sym, int freq);//констр
    char get_sym() const;//геттер символа
    int get_freq() const;//геттер частоты
    HuffmanNode* get_left() const;
    HuffmanNode* get_right() const;
    void set_left(HuffmanNode* node);
    void set_right(HuffmanNode* node);
};
class NodeComparator {//компаратор для мин-кучи
public:
    bool operator()(HuffmanNode* a, HuffmanNode* b) const;
};
class HuffmanCoder {
private:
    std::string text;//исходный текст
    std::map<char, int> freqs;//таблица частот
    std::map<char, std::string> codes;//таблица кодов
    HuffmanNode* root;//корень дерева
    int totalBits;//общее кол-во бит по Хаффману
    std::string encodedBits;//закодированная битовая строка
    void buildTree();//построение дерева
    void generateCodes(HuffmanNode* node, std::string code);//генерация кодов
    void deleteTree(HuffmanNode* node);//очистка памяти
    void printTreeRecursive(HuffmanNode* node, int level) const;//вывод дерева
public:
    HuffmanCoder(const std::string& txt);//констр
    ~HuffmanCoder();//дестр
    void encode();//запуск кодирования
    std::string decode(const std::string& bits, HuffmanNode* treeRoot);//раскодирование
    std::string getEncodedBits() const { return encodedBits; }//геттер битовой строки
    std::string decodeFromTree(const std::string& bits) const;//раскодирование по готовому дереву
    void printTree() const;//вывод дерева
    void printTable() const;//вывод таблицы
    void printStats() const;//вывод статистики
    void printEncodedBits() const;//вывод битовой строки
    void printDecoded(const std::string& bits, HuffmanNode* tree);//вывод раскодированного
};