#pragma once
#include <string>
class Node2 {
private:
    int type;//0=чис,1=x,2=операция
    int val;//код операции
    Node2* l;//левый
    Node2* r;//правый
public:
    Node2(int t, int v) : type(t), val(v), l(nullptr), r(nullptr) {}
    int get_type() const { return type; }
    int get_val() const { return val; }
    Node2* get_l() const { return l; }
    Node2* get_r() const { return r; }
    void set_l(Node2* node) { l = node; }
    void set_r(Node2* node) { r = node; }
    void set_val(int v) { val = v; }
};
class ExprTree2 {
private:
    Node2* root;//корень
    Node2* base(const std::string& expr, int& pos);//число/x/(...)
    Node2* power(const std::string& expr, int& pos);//^
    Node2* mulDiv(const std::string& expr, int& pos);//* / %
    Node2* addMin(const std::string& expr, int& pos);//+ -
    int priority(char op);//приоритет
    int operat(int a, int b, int op);//вычисление операции
    int calcut(Node2* node, int x);//значение при x
    void swapAddX(Node2* node);//замена A+x на x+A
    void toPrefix(Node2* node, std::string& res);//префиксная
    void toPostfix(Node2* node, std::string& res);//постфиксная
    void toInfix(Node2* node, std::string& res);//инфиксная с изб скобками
    void deleteTree(Node2* node);//очистка
    void printTree(Node2* node, int level);//вывод боком
public:
    ExprTree2(const std::string& expr);//констр
    ~ExprTree2();//дестр
    int compute(int x);//вычисление
    void transform();//замена A+x на x+A
    void print();//вывод
    std::string getPrefix();//префиксная строка
    std::string getPostfix();//постфиксная строка
    std::string getInfix();//инфиксная с изб скобками
};