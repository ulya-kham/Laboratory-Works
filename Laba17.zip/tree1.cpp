﻿#include "tree1.h"
#include <iostream>
#include <sstream>
#include <stack>
Node* ExprTree::buildTreePostf(const std::string& str) {//постр дер из опз
    std::istringstream iss(str);
    std::string tok;
    std::stack<Node*> st;
    while (iss >> tok) {
        if (tok == "+" || tok == "-" || tok == "*") {
            Node* r = st.top(); st.pop();
            Node* l = st.top(); st.pop();
            int code = (tok == "+") ? -1 : (tok == "-") ? -2 : -3;
            Node* op = new Node(code);
            op->set_l(l);
            op->set_r(r);
            st.push(op);
        }
        else st.push(new Node(std::stoi(tok)));
    }
    return st.top();
}
void ExprTree::printTree(Node* node, int level) {//вывод дерева боком
    if (!node) return;
    printTree(node->get_r(), level + 1);
    for (int i = 0; i < level; ++i) std::cout << "    ";
    if (node->get_val() < 0) {
        char op = (node->get_val() == -1) ? '+' : (node->get_val() == -2) ? '-' : '*';
        std::cout << op << "\n";
    }
    else std::cout << node->get_val() << "\n";
    printTree(node->get_l(), level + 1);
}
void ExprTree::deleteTree(Node* node) {//очистка памяти
    if (!node) return;
    deleteTree(node->get_l());
    deleteTree(node->get_r());
    delete node;
}
int ExprTree::calcul(Node* node) {//вычисление поддерева
    if (node->get_val() >= 0) return node->get_val();
    int l = calcul(node->get_l());
    int r = calcul(node->get_r());
    switch (node->get_val()) {
    case -1: return l + r;
    case -2: return l - r;
    case -3: return l * r;
    default: return 0;
    }
}
Node* ExprTree::deleteMinus(Node* node) {//удаление вычитаний (замена на знач)
    if (!node) return nullptr;
    if (node->get_val() == -2) {
        int val = calcul(node);
        deleteTree(node);
        return new Node(val);
    }
    node->set_l(deleteMinus(node->get_l()));
    node->set_r(deleteMinus(node->get_r()));
    return node;
}
ExprTree::ExprTree(const std::string& expr) { root = buildTreePostf(expr); }
ExprTree::~ExprTree() { deleteTree(root); }
void ExprTree::print() { printTree(root, 0); }
void ExprTree::deleteMinus() { root = deleteMinus(root); }
void ExprTree::toInfix(Node* node, std::string& res) {//инфиксная запись
    if (!node) return;
    if (node->get_val() >= 0) {
        res += std::to_string(node->get_val());
        return;
    }
    res += "(";
    toInfix(node->get_l(), res);
    char op = (node->get_val() == -1) ? '+' : (node->get_val() == -2) ? '-' : '*';
    res += " "; res += op; res += " ";
    toInfix(node->get_r(), res);
    res += ")";
}
std::string ExprTree::toInfix() {
    std::string res;
    toInfix(root, res);
    return res;
}
int ExprTree::getRootValue() { return root ? root->get_val() : 0; }
std::string ExprTree::getRootInfo() {//инфо о корне
    if (!root) return "пусто";
    if (root->get_val() >= 0) return std::to_string(root->get_val());
    switch (root->get_val()) {
    case -1: return "+";
    case -2: return "-";
    case -3: return "*";
    default: return "?";
    }
}