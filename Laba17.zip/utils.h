#pragma once
#include <vector>
#include <string>
class Utils {
public:
    static int get_int(const std::string& prompt = "");//ввод целого
    static int get_pos(const std::string& prompt = "");//>0
    static void fill_vector(std::vector<int>& vec, int method, int n = 0);//заполн вектора
    static void read_file_vec(std::vector<int>& vec);//чтение из файла
    static void write_expr_to_file(const std::string& filename);//запись обр пол запись 3 спос
    static bool is_valid_postfix(const std::string& expr);//проверка опз
    static std::string read_infix_from_file(const std::string& filename);//чтение инфикс из файла
    static int get_x();//ввод x
    static void write_to_file_and_cout(const std::string& filename, const std::string& data);//вывод в файл и консоль
    static void write_infix_to_file(const std::string& filename);//запись инфикса 3 спос
    static bool is_valid_infix(const std::string& expr);//проверка инфикса
};