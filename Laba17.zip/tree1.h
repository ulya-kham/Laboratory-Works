#pragma once
#include <string>
#include <stack>
class Node {
private:
    int val;//знач операции
    Node* l;//левый
    Node* r;//правый
public:
    Node(int v) : val(v), l(nullptr), r(nullptr) {}
    int get_val() const { return val; }
    Node* get_l() const { return l; }
    Node* get_r() const { return r; }
    void set_l(Node* node) { l = node; }
    void set_r(Node* node) { r = node; }
};
class ExprTree {
private:
    Node* root;//корень
    Node* buildTreePostf(const std::string& expr);//постр дерева из опз
    void printTree(Node* node, int level);//вывод боком
    void deleteTree(Node* node);//очистка памяти
    int calcul(Node* node);//вычисление поддерева
    Node* deleteMinus(Node* node);//удаление вычитаний
    void toInfix(Node* node, std::string& res);//инфиксная запись
public:
    ExprTree(const std::string& expr);//констр
    ~ExprTree();//дестр
    void print();//вывод
    void deleteMinus();//удалить вычитания
    Node* getRoot() { return root; }//геттер корня
    int getRootValue();//знач корня
    std::string toInfix();//инфиксная строка
    std::string getRootInfo();//инфо о корне
};