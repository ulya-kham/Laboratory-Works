#include "tree23.h"
#include <iostream>
#include <cctype>
void skipSpaces(const std::string& expr, int& pos) {//пропуск пробелов
    while (pos < (int)expr.size() && expr[pos] == ' ') pos++;
}
Node2* ExprTree2::base(const std::string& str, int& pos) {//число/x/()
    skipSpaces(str, pos);
    if (pos >= (int)str.size()) return nullptr;
    if (str[pos] == '(') {
        pos++;
        Node2* node = addMin(str, pos);
        skipSpaces(str, pos);
        if (pos < (int)str.size() && str[pos] == ')') pos++;
        return node;
    }
    if (std::isdigit(str[pos])) {
        int val = 0;
        while (pos < (int)str.size() && std::isdigit(str[pos])) {
            val = val * 10 + (str[pos] - '0');
            pos++;
        }
        return new Node2(0, val);
    }
    if (str[pos] == 'x') {
        pos++;
        return new Node2(1, 0);
    }
    return nullptr;
}
Node2* ExprTree2::power(const std::string& expr, int& pos) {//^ (левая ассоц)
    Node2* node = base(expr, pos);
    while (true) {
        skipSpaces(expr, pos);
        if (pos >= (int)expr.size() || expr[pos] != '^') break;
        pos++;
        Node2* right = base(expr, pos);
        Node2* parent = new Node2(2, -6);
        parent->set_l(node);
        parent->set_r(right);
        node = parent;
    }
    return node;
}
Node2* ExprTree2::mulDiv(const std::string& expr, int& pos) {//* / %
    Node2* node = power(expr, pos);
    while (true) {
        skipSpaces(expr, pos);
        if (pos >= (int)expr.size()) break;
        char op = expr[pos];
        if (op != '*' && op != '/' && op != '%') break;
        pos++;
        Node2* right = power(expr, pos);
        int code = (op == '*') ? -3 : (op == '/') ? -4 : -5;
        Node2* parent = new Node2(2, code);
        parent->set_l(node);
        parent->set_r(right);
        node = parent;
    }
    return node;
}
Node2* ExprTree2::addMin(const std::string& expr, int& pos) {//+ -
    Node2* node = mulDiv(expr, pos);
    while (true) {
        skipSpaces(expr, pos);
        if (pos >= (int)expr.size()) break;
        char op = expr[pos];
        if (op != '+' && op != '-') break;
        pos++;
        Node2* right = mulDiv(expr, pos);
        int code = (op == '+') ? -1 : -2;
        Node2* parent = new Node2(2, code);
        parent->set_l(node);
        parent->set_r(right);
        node = parent;
    }
    return node;
}
int ExprTree2::priority(char op) {//приоритет операции
    if (op == '+' || op == '-') return 1;
    if (op == '*' || op == '/' || op == '%') return 2;
    if (op == '^') return 3;
    return 0;
}
int ExprTree2::operat(int a, int b, int op) {//вычисление операции
    switch (op) {
    case -1: return a + b;
    case -2: return a - b;
    case -3: return a * b;
    case -4: // деление
        if (b == 0) {
            std::cerr << "\n\tделение на ноль! Возвращаем 0.\n";
            return 0;
        }
        return a / b;
    case -5: // остаток
        if (b == 0) {
            std::cerr << "\n\t⚠️остаток от деления на ноль! Возвращаем 0.\n";
            return 0;
        }
        return a % b;
    case -6: { // степень
        if (b < 0) {
            std::cerr << "\n\t отрицательная степень! Возвращаем 0.\n";
            return 0;
        }
        int res = 1;
        for (int i = 0; i < b; ++i) res *= a;
        return res;
    }
    default: return 0;
    }
}
int ExprTree2::calcut(Node2* node, int x) {//вычисление поддерева
    if (!node) return 0;
    if (node->get_type() == 0) return node->get_val();
    if (node->get_type() == 1) return x;
    int l = calcut(node->get_l(), x);
    int r = calcut(node->get_r(), x);
    return operat(l, r, node->get_val());
}
void ExprTree2::swapAddX(Node2* node) {//замена A+x на x+A
    if (!node) return;
    if (node->get_type() == 2 && node->get_val() == -1 &&
        node->get_r() && node->get_r()->get_type() == 1) {
        Node2* tmp = node->get_l();
        node->set_l(node->get_r());
        node->set_r(tmp);
    }
    swapAddX(node->get_l());
    swapAddX(node->get_r());
}
void ExprTree2::toPrefix(Node2* node, std::string& res) {//префиксная запись
    if (!node) return;
    if (node->get_type() == 0) res += std::to_string(node->get_val()) + " ";
    else if (node->get_type() == 1) res += "x ";
    else {
        char op = '?';
        switch (node->get_val()) {
        case -1: op = '+'; break; case -2: op = '-'; break;
        case -3: op = '*'; break; case -4: op = '/'; break;
        case -5: op = '%'; break; case -6: op = '^'; break;
        }
        res += op; res += " ";
        toPrefix(node->get_l(), res);
        toPrefix(node->get_r(), res);
    }
}
void ExprTree2::toPostfix(Node2* node, std::string& res) {//постфиксная запись
    if (!node) return;
    toPostfix(node->get_l(), res);
    toPostfix(node->get_r(), res);
    if (node->get_type() == 0) res += std::to_string(node->get_val()) + " ";
    else if (node->get_type() == 1) res += "x ";
    else {
        char op = '?';
        switch (node->get_val()) {
        case -1: op = '+'; break; case -2: op = '-'; break;
        case -3: op = '*'; break; case -4: op = '/'; break;
        case -5: op = '%'; break; case -6: op = '^'; break;
        }
        res += op; res += " ";
    }
}
void ExprTree2::toInfix(Node2* node, std::string& res) {//инфикс с изб скобками
    if (!node) return;
    if (node->get_type() == 0) res += std::to_string(node->get_val());
    else if (node->get_type() == 1) res += "x";
    else {
        res += "(";
        toInfix(node->get_l(), res);
        char op = '?';
        switch (node->get_val()) {
        case -1: op = '+'; break; case -2: op = '-'; break;
        case -3: op = '*'; break; case -4: op = '/'; break;
        case -5: op = '%'; break; case -6: op = '^'; break;
        }
        res += " "; res += op; res += " ";
        toInfix(node->get_r(), res);
        res += ")";
    }
}
void ExprTree2::deleteTree(Node2* node) {//очистка памяти
    if (!node) return;
    deleteTree(node->get_l());
    deleteTree(node->get_r());
    delete node;
}
void ExprTree2::printTree(Node2* node, int level) {//вывод дерева боком
    if (!node) return;
    printTree(node->get_r(), level + 1);
    for (int i = 0; i < level; ++i) std::cout << "    ";
    if (node->get_type() == 0) std::cout << node->get_val() << "\n";
    else if (node->get_type() == 1) std::cout << "x\n";
    else {
        char op = '?';
        switch (node->get_val()) {
        case -1: op = '+'; break; case -2: op = '-'; break;
        case -3: op = '*'; break; case -4: op = '/'; break;
        case -5: op = '%'; break; case -6: op = '^'; break;
        }
        std::cout << op << "\n";
    }
    printTree(node->get_l(), level + 1);
}
ExprTree2::ExprTree2(const std::string& expr) {
    int pos = 0;
    root = addMin(expr, pos);
}
ExprTree2::~ExprTree2() { deleteTree(root); }
int ExprTree2::compute(int x) { return calcut(root, x); }
void ExprTree2::transform() { swapAddX(root); }
void ExprTree2::print() { printTree(root, 0); }
std::string ExprTree2::getPrefix() {
    std::string res;
    toPrefix(root, res);
    return res;
}
std::string ExprTree2::getPostfix() {
    std::string res;
    toPostfix(root, res);
    return res;
}
std::string ExprTree2::getInfix() {
    std::string res;
    toInfix(root, res);
    return res;
}