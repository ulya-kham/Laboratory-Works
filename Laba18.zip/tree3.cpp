#include "tree3.h"
#include <iostream>
Node3::Node3(int k) : key(k), left(nullptr), right(nullptr) {}//констр
int Node3::get_key() const { return key; }//геттер
Node3* Node3::get_left() const { return left; }
Node3* Node3::get_right() const { return right; }
void Node3::set_left(Node3* node) { left = node; }
void Node3::set_right(Node3* node) { right = node; }
TreeIterator::TreeIterator(Node3* root) : curr(root) {}//констр
bool TreeIterator::has_next() {//проверка наличия следующего
    return !st.empty() || curr != nullptr;
}
int TreeIterator::next() {//возвращает след лпк
    while (curr != nullptr) {//идем влево до упора
        st.push(curr);
        curr = curr->get_left();
    }
    Node3* node = st.top();//берем верхний
    st.pop();
    curr = node->get_right();//идем на правок
    return node->get_key();
}
TreeFun3::TreeFun3() : root(nullptr) {}//констр
TreeFun3::~TreeFun3() { cleanup(); }//дестр
void TreeFun3::build(const std::vector<int>& data) {
    if (data.empty()) return;
    std::queue<Node3*> q;
    root = new Node3(data[0]);
    q.push(root);
    int i = 1;
    while (!q.empty() && i < data.size()) {
        Node3* cur = q.front(); q.pop();
        if (i < data.size()) {
            cur->set_left(new Node3(data[i++]));
            q.push(cur->get_left());
        }
        if (i < data.size()) {
            cur->set_right(new Node3(data[i++]));
            q.push(cur->get_right());
        }
    }
}
void TreeFun3::print() const { print_node(root, 0); }
void TreeFun3::print_node(Node3* node, int level) const {//вывод дерева боком
    if (!node) return;
    print_node(node->get_right(), level + 1);
    for (int i = 0; i < level; ++i) std::cout << "    ";
    std::cout << node->get_key() << "\n";
    print_node(node->get_left(), level + 1);
}
void TreeFun3::cleanup() { clear_node(root); root = nullptr; }//очистка
void TreeFun3::clear_node(Node3* node) {//удаление
    if (!node) return;
    clear_node(node->get_left());
    clear_node(node->get_right());
    delete node;
}
TreeIterator TreeFun3::get_iter() const { return TreeIterator(root); }//итератор