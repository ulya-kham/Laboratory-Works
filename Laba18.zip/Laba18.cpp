﻿#include <iostream>
#include <limits>
#include <windows.h>
#include "utils.h"
#include "tree1.h"
#include "tree3.h"
#include "tree11.h"
void menu_treefun1();
void menu_treefun3();
void menu_treefun11();
int main() {
    ::SetConsoleCP(1251);
    ::SetConsoleOutputCP(1251);
    ::setlocale(LC_ALL, "Russian");
    int choice;
    do {
        std::cout << "\n\t\t~~ Лабораторная работа №18 (Деревья и Списки) ~~\n\n";
        std::cout << "\t1. Задача 1 – Преобразовать дерево в двусвязный список (TreeFun1)\n";
        std::cout << "\t2. Задача 2 – Итератор обхода (TreeFun3)\n";
        std::cout << "\t3. Задача 3 – Пожар дерева (TreeFun11)\n";
        std::cout << "\t0. Выход\n";
        choice = Utils::get_int("\n\tВыбери задание: ");
        while (choice < 0 || choice > 3) {
            std::cout << "\n\tОшибочка( выбери 0 или 3!\n";
            choice = Utils::get_int("\n\tВыбери задание: ");
        }
        ::system("cls");
        switch (choice) {
        case 1: menu_treefun1(); break;
        case 2: menu_treefun3(); break;
        case 3: menu_treefun11(); break;
        case 0: std::cout << "\n\tПока-пока))\n\n"; break;
        }
        if (choice != 0) {
            std::cout << "\n\tНажми что-нибудь для возврата в меню...";
            std::cin.get();
            std::cin.get();
            ::system("cls");
        }
    } while (choice != 0);
    return 0;
}
void menu_treefun1() {
    std::cout << "\n\t~~ Задача 1 – Преобразовать дерево в двусвязный список (TreeFun1) ~~\n";
    std::cout << "\n\tКак заполнить данные?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    std::vector<int> values;
    int n = Utils::get_pos();
    Utils::fill_vec_bst(values, method, n);
    std::cout << "\n\tИсходный массив (после фильтрации дублей):\n\t";
    for (int x : values) 
        std::cout << x << " ";
    TreeFun1 bst;
    bst.build_vector(values);
    std::cout << "\n\n\tИсходное дерево поиска:\n";
    bst.show();
    Node* list_head = bst.convert_to_list();
    std::cout << "\n\tДвусвязный список:\n\t";
    bst.show_list(list_head);
    std::cout << "\n";
    bst.cleanup();
    std::cin.get();
}
void menu_treefun3() {
    std::cout << "\n\t~~ Задача 3 – Итератор для бинарного дерева (TreeFun3) ~~\n";
    std::cout << "\n\tКак заполнить данные?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    std::vector<int> values;
    int n = Utils::get_pos();
    Utils::fill_vector(values, method, n);
    std::cout << "\n\tИсходный массив:\n\t";
    for (int x : values) 
        std::cout << x << " ";
    TreeFun3 tree;
    tree.build(values);
    std::cout << "\n\n\tИсходное бинарное дерево:\n";
    tree.print();
    std::cout << "\n\tОбход итератором (лево-корень-право):\n\t";
    TreeIterator it = tree.get_iter();
    while (it.has_next()) {
        std::cout << it.next() << " ";
    }
    std::cout << "\n";
    tree.cleanup();
    std::cin.get();
}
void menu_treefun11() {
    std::cout << "\n\t~~ Задача 3 – Исследование бинарных деревьев (TreeFun11) ~~\n";
    std::cout << "\n\tКак заполнить данные?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    std::vector<int> values;
    int n = Utils::get_pos();
    Utils::fill_vector(values, method, n);
    std::cout << "\n\tИсходный массив:\n\t";
    for (int x : values) 
        std::cout << x << " ";
    TreeFun11 tree;
    tree.build(values);
    std::cout << "\n\n\tИсходное бинарное дерево:\n";
    tree.print();
    int start_val;
    std::vector<int> burn_order;
    do {
        start_val = Utils::get_int("\n\tВведи значение узла, с которого начнётся пожар:) ");
        burn_order = tree.burn_from(start_val);
        if (burn_order.empty()) {
            std::cout << "\n\tОшибочка( такого узелка нет в дереве! Попробуй ввести другое число, чтобы сгорело всё к чертям;)\n";
        }
    } while (burn_order.empty());
    std::cout << "\n\tПорядок сгорания узлов: ";
    for (int x : burn_order) std::cout << x << " -> ";
    std::cout << "Всё испепелилось\n";
    tree.cleanup();
    std::cin.get();
}