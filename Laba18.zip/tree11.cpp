#include "tree11.h"
#include <iostream>
Node11::Node11(int k) : key(k), left(nullptr), right(nullptr) {}//констр
int Node11::get_key() const { return key; }
Node11* Node11::get_left() const { return left; }
Node11* Node11::get_right() const { return right; }
void Node11::set_left(Node11* node) { left = node; }
void Node11::set_right(Node11* node) { right = node; }
TreeFun11::TreeFun11() : root(nullptr) {}//констр
TreeFun11::~TreeFun11() { cleanup(); }//дестр
void TreeFun11::build(const std::vector<int>& data) {//постр дерева уровнями
    if (data.empty()) return;
    std::queue<Node11*> q;
    root = new Node11(data[0]);
    q.push(root);
    int i = 1;
    while (!q.empty() && i < data.size()) {
        Node11* cur = q.front(); q.pop();
        if (i < data.size()) {
            cur->set_left(new Node11(data[i++]));
            q.push(cur->get_left());
        }
        if (i < data.size()) {
            cur->set_right(new Node11(data[i++]));
            q.push(cur->get_right());
        }
    }
}
void TreeFun11::print() const { print_node(root, 0); }//публичный вывод
void TreeFun11::print_node(Node11* node, int level) const {//вывод дерева боком
    if (!node) return;
    print_node(node->get_right(), level + 1);
    for (int i = 0; i < level; ++i) std::cout << "    ";
    std::cout << node->get_key() << "\n";
    print_node(node->get_left(), level + 1);
}
Node11* TreeFun11::find_node(int val) const {//поиск узла клп
    if (!root) return nullptr;
    std::queue<Node11*> q;
    q.push(root);
    while (!q.empty()) {
        Node11* cur = q.front(); q.pop();
        if (cur->get_key() == val) return cur;
        if (cur->get_left()) q.push(cur->get_left());
        if (cur->get_right()) q.push(cur->get_right());
    }
    return nullptr;
}
std::unordered_map<Node11*, Node11*> TreeFun11::build_parents() const {//сбор родителей
    std::unordered_map<Node11*, Node11*> parents;
    if (!root) return parents;
    std::queue<Node11*> q;
    q.push(root);
    parents[root] = nullptr;
    while (!q.empty()) {
        Node11* cur = q.front(); q.pop();
        if (cur->get_left()) {
            parents[cur->get_left()] = cur;
            q.push(cur->get_left());
        }
        if (cur->get_right()) {
            parents[cur->get_right()] = cur;
            q.push(cur->get_right());
        }
    }
    return parents;
}
std::vector<int> TreeFun11::burn_from(int start_val) const {//пожар лпк от старта
    std::vector<int> order;
    Node11* start = find_node(start_val);
    if (!start) return order;
    auto parents = build_parents();
    std::queue<Node11*> q;
    std::unordered_set<Node11*> visited;
    q.push(start);
    visited.insert(start);
    while (!q.empty()) {
        Node11* cur = q.front(); q.pop();
        order.push_back(cur->get_key());
        Node11* neigh[3] = { cur->get_left(), cur->get_right(), parents[cur] };
        for (Node11* nb : neigh) {
            if (nb && visited.find(nb) == visited.end()) {
                visited.insert(nb);
                q.push(nb);
            }
        }
    }
    return order;
}
void TreeFun11::cleanup() { clear_node(root); root = nullptr; }//очистка
void TreeFun11::clear_node(Node11* node) {//рекурсивное удаление
    if (!node) return;
    clear_node(node->get_left());
    clear_node(node->get_right());
    delete node;
}