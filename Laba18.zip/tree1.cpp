#include "tree1.h"
#include <iostream>
Node::Node(int k) : key(k), left(nullptr), right(nullptr) {}//констр
int Node::get_key() const { return key; }//геттер ключ
Node* Node::get_left() const { return left; }//геттер лев
Node* Node::get_right() const { return right; }//геттер прав
void Node::set_left(Node* node) { left = node; }//сеттер лев
void Node::set_right(Node* node) { right = node; }//сеттер прав
TreeFun1::TreeFun1() : root(nullptr) {}//констр
TreeFun1::~TreeFun1() { clear(root); }//дестр
void TreeFun1::build_vector(const std::vector<int>& data) {//постр дерева из вектора
    for (int val : data) {
        if (!root) root = new Node(val);
        else add(root, val);
    }
}
void TreeFun1::add(Node* node, int val) {//добавл
    if (val == node->get_key()) return;//дубликаты игнор
    if (val < node->get_key()) {
        if (!node->get_left()) node->set_left(new Node(val));
        else add(node->get_left(), val);
    }
    else {
        if (!node->get_right()) node->set_right(new Node(val));
        else add(node->get_right(), val);
    }
}
void TreeFun1::show() const { print(root, 0); }
void TreeFun1::print(Node* node, int level) const {//вывод дерева боком
    if (!node) return;
    print(node->get_right(), level + 1);//сначала правое
    for (int i = 0; i < level; ++i) 
        std::cout << "    ";
    std::cout << node->get_key() << "\n";
    print(node->get_left(), level + 1);
}
Node* TreeFun1::convert_to_list() {//преобр дерева в двусвязный список
    Node* head = nullptr;//нач списка
    Node* prev = nullptr;//послед узел
    convert(root, head, prev);
    root = nullptr;//дестр не удалял улы
    return head;
}
void TreeFun1::convert(Node* node, Node*& head, Node*& prev) {//рекурсивное преобр
    if (!node) return;
    convert(node->get_left(), head, prev);//сначала левое
    if (!head) head = node;//1 узел -начало списка
    if (prev) {
        node->set_left(prev);//левы1-предыдущ
        prev->set_right(node);//правый предыдуще-текущий
    }
    prev = node;//текущ = предыдущ
    convert(node->get_right(), head, prev);//потом правое
}
void TreeFun1::show_list(Node* head) const {//вывод списка
    Node* curr = head;
    while (curr) {
        std::cout << curr->get_key() << " <=> ";
        curr = curr->get_right();//идём по некст
    }
    std::cout << "null\n";
}
void TreeFun1::cleanup() {//очистка
    clear(root);
    root = nullptr;
}
void TreeFun1::clear(Node* node) {//удаление
    if (!node) return;
    clear(node->get_left());
    clear(node->get_right());
    delete node;
}