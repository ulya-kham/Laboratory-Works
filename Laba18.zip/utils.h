#pragma once
#include <vector>
#include <string>
class Utils {
public:
    static int get_int(const std::string& prompt = "");//ввод целого
    static int get_pos(const std::string& prompt = "");//>0
    static void fill_vector(std::vector<int>& vec, int method, int n = 0);//заполн вектора
    static void read_file_vec(std::vector<int>& vec);//чтение из файла
    static int get_x();//ввод x
    static void write_file(const std::string& filename, const std::string& data);//вывод в файл и консоль
    static void fill_vec_bst(std::vector<int>& vec, int method, int n);//заполнение без дублей
};