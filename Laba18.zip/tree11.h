#pragma once
#include <vector>
#include <queue>
#include <unordered_map>
#include <unordered_set>
class Node11 {
private:
    int key;//знач
    Node11* left;//лев
    Node11* right;//прав
public:
    Node11(int k);//констр
    int get_key() const;//геттер
    Node11* get_left() const;
    Node11* get_right() const;
    void set_left(Node11* node);
    void set_right(Node11* node);
};
class TreeFun11 {
private:
    Node11* root;//корень
    void print_node(Node11* node, int level) const;//вывод 
    void clear_node(Node11* node);//очистка
    Node11* find_node(int val) const;//поиск узла по знач (обход в ширину)
    std::unordered_map<Node11*, Node11*> build_parents() const;//карта родителе
public:
    TreeFun11();//констр
    ~TreeFun11();//дестр
    void build(const std::vector<int>& data);//постр дерева из масива по уровням
    void print() const;//вывод
    std::vector<int> burn_from(int start_val) const;//порядок сжигания от старта
    void cleanup();//очистка
};