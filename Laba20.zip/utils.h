#pragma once
#include <string>
#include <vector>
#include <limits>
class Utils {
public:
    static int get_int(const std::string& prompt = "");//ввод целого
    static int get_pos(const std::string& prompt = "");//ввод >0
    static std::string get_filename(const std::string& prompt = "");//ввод имени файла
    static unsigned int get_unsigned(const std::string& prompt);//ввод неотрицательного целого
};