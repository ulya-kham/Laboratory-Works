﻿#include <iostream>
#include <windows.h>
#include <fstream>
#include <random>
#include <sstream>
#include "time.h"
#include "utils.h"
void menu_task1();
int main() {
    ::SetConsoleCP(1251);
    ::SetConsoleOutputCP(1251);
    ::setlocale(LC_ALL, "Russian");
    int choice;
    do {
        std::cout << "\n\t\t~~ Лабораторная работа №20 (Класс. Перегрузка операторов) ~~\n\n";
        std::cout << "\t1. Время (Time)\n";
        std::cout << "\t0. Выход\n";
        choice = Utils::get_int("\n\tВыбери задание: ");
        while (choice < 0 || choice > 1) {
            std::cout << "\n\tОшибочка( выбери 0 или 1!\n";
            choice = Utils::get_int("\n\tВыбери задание: ");
        }
        ::system("cls");
        switch (choice) {
        case 1: menu_task1(); break;
        case 0: std::cout << "\n\tПока-пока))\n\n"; break;
        }
        if (choice != 0) {
            std::cout << "\n\tНажми Enter для возврата в меню...";
            std::cin.get();
            std::cin.get();
            ::system("cls");
        }
    } while (choice != 0);
    return 0;
}
void menu_task1() {//меню для задачи 1
    std::cout << "\n\t~~ Задача 1 – Время (Time) ~~\n";
    std::cout << "\n\tКак заполнить данные?\n";
    std::cout << "\t1. С клавиатуры\n\t2. Случайно\n\t3. Из файла\n";
    int method = Utils::get_int("\n\tВыбери: ");
    while (method < 1 || method > 3) {
        std::cout << "\n\tОшибочка( выбери 1, 2 или 3... Давай по новой: ";
        method = Utils::get_int();
    }
    Time t;
    if (method == 1) {
        std::cin >> t;
    }
    else if (method == 2) {
        std::random_device rd;
        std::mt19937 gen(rd());
        t.set(gen() % 24, gen() % 60);
        std::cout << "\n\tСлучайное время t: " << t << "\n";
    }
    else if (method == 3) {
        std::string filename;
        std::ifstream file;
        do {
            std::cout << "\n\tВведи имя файла (строка ЧЧ:ММ): ";
            std::cin >> filename;
            file.open(filename);
            if (!file.is_open()) std::cout << "\n\tОшибочка( файлик не найден!\n";
        } while (!file.is_open());
        std::string str;
        file >> str;
        file.close();
        int hh, mm;
        char sep;
        std::stringstream ss(str);
        if (ss >> hh >> sep >> mm && sep == ':' && hh >= 0 && hh < 24 && mm >= 0 && mm < 60)
            t.set(hh, mm);
        else {
            std::cout << "\n\tОшибочка( неверный формат в файлике\n";
            t.set(0, 0);
        }
        std::cout << "\n\tВремя из файлика t: " << t << "\n";
    }
    std::cout << "\n\t~ Основной объектик t ~\n";
    std::cout << "\tТекущее времечко t: " << t << "\n";
    std::cout << "\n\t~ Демонстрация конструкторов ~\n";
    Time t1;
    std::cout << "\tКонструктор по умолчанию t1: " << t1 << "\n";
    int hh = Utils::get_int("\tВведи часы для t2: ");
    int mm = Utils::get_int("\tВведи минуты для t2: ");
    Time t2(hh, mm);
    std::cout << "\tКонструктор с параметрами t2: " << t2 << "\n";
    Time t3 = t2;
    std::cout << "\tКонструктор копирования t3 (копия t2): " << t3 << "\n";
    std::cout << "\n\t~ Унарные операции (над косновным объектиком) ~\n";
    Time tt = t;
    std::cout << "\tИсходное tt: " << tt << "\n";
    std::cout << "\tПрефиксный ++tt: " << ++tt << "\n";
    std::cout << "\tПостфиксный tt++: " << tt++ << " (старое), теперь tt = " << tt << "\n";
    std::cout << "\tПрефиксный --tt: " << --tt << "\n";
    std::cout << "\tПостфиксный tt--: " << tt-- << " (старое), теперь tt = " << tt << "\n";
    std::cout << "\n\t~ Операции приведения типа (объект t) ~\n";
    std::cout << "\tКоличесвто минут с начала суток: " << (int)t << "\n";
    std::cout << "\tПриведенные часы: " << (short int)t << "\n";
    std::cout << "\tНеявное приведение к bool: " << (t ? "true (не 00:00)" : "false (00:00)") << "\n";
    std::cout << "\n\t~ Бинарные операции (основной объектик) ~\n";
    unsigned int mins = Utils::get_unsigned("\tВведи количество минут (целое, >=0): ");
    std::cout << "\tt + " << mins << " мин = " << t.addMinutes(mins) << "\n";
    std::cout << "\tt - " << mins << " мин = " << t.subMinutes(mins) << "\n";
    std::cout << "\tСравнение t и t2: ";
    if (t == t2) std::cout << "равны\n";
    else if (t < t2) std::cout << "t раньше, чем t2\n";
    else std::cout << "t позже, чем t2\n";
    std::cout << "\tРазность в минутах (t - t2): " << (t - t2) << "\n";
    std::cin.get();
}