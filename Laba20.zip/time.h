#pragma once
#include <iostream>
#include <string>
class Time {
private:
    unsigned char h;//часы
    unsigned char m;//минуты
    void norm();//привод к норме
public:
    Time();//по умолч
    Time(int h, int m);//с парам
    Time(const Time& other);//копир
    void set(int h, int m);//установка
    int getH() const;
    int getM() const;
    Time addMinutes(unsigned int mins) const;//добавка мин
    Time subMinutes(unsigned int mins) const;//вычесть мин
    int diff(const Time& other) const;//разница в минутах
    bool operator==(const Time& other) const;//логич выражения 
    bool operator!=(const Time& other) const;
    bool operator<(const Time& other) const;
    bool operator>(const Time& other) const;
    bool operator<=(const Time& other) const;
    bool operator>=(const Time& other) const;
    Time operator+(unsigned int mins) const;//арифметич операции
    Time operator-(unsigned int mins) const;
    int operator-(const Time& other) const;
    Time& operator+=(unsigned int mins);//составные присваивания
    Time& operator-=(unsigned int mins);
    Time& operator++();//префикс++
    Time operator++(int);//постфик ++
    Time& operator--();//префикс--
    Time operator--(int);//постфик--
    operator int() const;//приведение к инт
    friend std::ostream& operator<<(std::ostream& os, const Time& t);//ввод
    friend std::istream& operator>>(std::istream& is, Time& t);//вывод 
    void print() const;
    explicit operator short int() const;//приведение к часам
    operator bool() const;//приведение к бул
};